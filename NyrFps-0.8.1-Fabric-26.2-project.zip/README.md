# NyrFps 0.8.1 — Minecraft 26.2

Android-focused Fabric performance mod project built around the supplied NyrFps sources.

## Build on GitHub Actions
1. Upload the contents of this folder to a GitHub repository.
2. Push to `main` (or run **Actions → Build NyrFps → Run workflow**).
3. Open the successful workflow run and download the **NyrFps-26.2** artifact.
4. Put the generated NyrFps jar into MJLauncher `mods`.

This project does **not** start VulkanMod manually. If VulkanMod is installed, NyrFps can read its configuration through the supplied reflective code while VulkanMod keeps its own Fabric lifecycle. This avoids double-initialization.

Note: the supplied ZIP does not contain a real chunk engine implementation. `NyrFpsChunkEngine.java` here is a small compatibility policy bridge so the project can compile; it is not a full replacement for a renderer/chunk engine.
